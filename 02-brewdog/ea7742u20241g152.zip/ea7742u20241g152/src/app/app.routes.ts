import {Routes} from '@angular/router';
import {Home} from './shared/presentation/views/home/home';

const pageNotFound = () => import('./shared/presentation/views/page-not-found/page-not-found').then(m => m.PageNotFound);
const dispatchesRoutes = () => import('./dispatches/presentation/dispatches.routes').then(m => m.dispatchesRoutes);
const baseTitle = 'BrewDog Dispatch Logistics Platform';

/**
 * Root route configuration that composes bounded-context routes.
 *
 * @author Alexis Calin Torres Huaman
 */
export const routes: Routes = [
  { path: 'home',     component:     Home,             title: `${baseTitle} - Home` },
  { path: 'dispatch', loadChildren:  dispatchesRoutes },
  { path: '',         redirectTo:    '/home', pathMatch: 'full' },
  { path: '**',       loadComponent: pageNotFound,     title: `${baseTitle} - Page Not Found` }
];
